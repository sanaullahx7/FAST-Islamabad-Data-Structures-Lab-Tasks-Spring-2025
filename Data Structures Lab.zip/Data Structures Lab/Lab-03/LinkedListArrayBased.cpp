#include <iostream>
#define MAX_SIZE 100  // Maximum number of nodes

using namespace std;

class LinkedListArray {
private:
    int data[MAX_SIZE];   // Stores values
    int next[MAX_SIZE];   // Stores next indices
    int head;             // Index of the first node
    int freeIndex;        // Index of the next free slot

public:
    LinkedListArray() {
        head = -1;   // Empty list
        freeIndex = 0; // Start allocating from index 0

        // Initialize the next array for available slots
        for (int i = 0; i < MAX_SIZE - 1; i++) {
            next[i] = i + 1; // Next free slot
        }
        next[MAX_SIZE - 1] = -1; // End of available slots
    }

    // Insert at the beginning
    void insertAtBeginning(int value) {
        if (freeIndex == -1) {
            cout << "List is full!" << endl;
            return;
        }

        int newIndex = freeIndex;
        freeIndex = next[freeIndex]; // Update freeIndex

        data[newIndex] = value;
        next[newIndex] = head; // Link to previous head
        head = newIndex; // Update head
    }

    // Insert at the end
    void insertAtEnd(int value) {
        if (freeIndex == -1) {
            cout << "List is full!" << endl;
            return;
        }

        int newIndex = freeIndex;
        freeIndex = next[freeIndex];

        data[newIndex] = value;
        next[newIndex] = -1;

        if (head == -1) {
            head = newIndex;
            return;
        }

        int temp = head;
        while (next[temp] != -1) {
            temp = next[temp];
        }
        next[temp] = newIndex;
    }

    // Insert at a specific index
    void insertAtIndex(int value, int index) {
        if (freeIndex == -1) {
            cout << "List is full!" << endl;
            return;
        }

        if (index == 0) {
            insertAtBeginning(value);
            return;
        }

        int temp = head;
        for (int i = 0; temp != -1 && i < index - 1; i++) {
            temp = next[temp];
        }

        if (temp == -1) {
            cout << "Invalid index!" << endl;
            return;
        }

        int newIndex = freeIndex;
        freeIndex = next[freeIndex];

        data[newIndex] = value;
        next[newIndex] = next[temp];
        next[temp] = newIndex;
    }

    // Delete from the beginning
    void deleteAtBeginning() {
        if (head == -1) {
            cout << "List is empty!" << endl;
            return;
        }

        int temp = head;
        head = next[head];
        next[temp] = freeIndex;
        freeIndex = temp;
    }

    // Delete from the end
    void deleteAtEnd() {
        if (head == -1) {
            cout << "List is empty!" << endl;
            return;
        }

        if (next[head] == -1) {
            freeIndex = head;
            head = -1;
            return;
        }

        int temp = head;
        while (next[next[temp]] != -1) {
            temp = next[temp];
        }

        int last = next[temp];
        next[temp] = -1;
        next[last] = freeIndex;
        freeIndex = last;
    }

    // Delete at a specific index
    void deleteAtIndex(int index) {
        if (head == -1) {
            cout << "List is empty!" << endl;
            return;
        }

        if (index == 0) {
            deleteAtBeginning();
            return;
        }

        int temp = head;
        for (int i = 0; temp != -1 && i < index - 1; i++) {
            temp = next[temp];
        }

        if (temp == -1 || next[temp] == -1) {
            cout << "Invalid index!" << endl;
            return;
        }

        int nodeToDelete = next[temp];
        next[temp] = next[nodeToDelete];
        next[nodeToDelete] = freeIndex;
        freeIndex = nodeToDelete;
    }

    // Search for an element
    bool search(int key) {
        int temp = head;
        while (temp != -1) {
            if (data[temp] == key) return true;
            temp = next[temp];
        }
        return false;
    }

    // Traverse and print the list
    void traverse() {
        int temp = head;
        while (temp != -1) {
            cout << data[temp] << " -> ";
            temp = next[temp];
        }
        cout << "NULL" << endl;
    }

    void reverse() {
        if (head == -1 || next[head] == -1) return;
        int prev = -1, current = head, nextNode;
        while (current != -1) {
            nextNode = next[current];
            next[current] = prev;
            prev = current;
            current = nextNode;
        }
        head = prev;
    }
};

// Main function
int main() {
    LinkedListArray list;

    list.insertAtBeginning(10);
    list.insertAtBeginning(5);
    list.insertAtEnd(20);
    list.insertAtEnd(25);
    list.insertAtIndex(15, 2);

    cout << "Linked List: ";
    list.traverse();

    cout << "Deleting at beginning..." << endl;
    list.deleteAtBeginning();
    list.traverse();

    cout << "Deleting at end..." << endl;
    list.deleteAtEnd();
    list.traverse();

    cout << "Deleting at index 1..." << endl;
    list.deleteAtIndex(1);
    list.traverse();

    list.reverse();
    cout<<"\n\nReversed List\n";
    list.traverse();

    int key = 15;
    cout << "Searching for " << key << ": " << (list.search(key) ? "Found" : "Not Found") << endl;

    return 0;
}
