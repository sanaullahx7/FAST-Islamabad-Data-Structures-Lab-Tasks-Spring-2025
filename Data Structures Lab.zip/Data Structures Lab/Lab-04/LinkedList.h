//Muhammad Mudassir
//I23-2562
//DS-4A
//Lab-04

#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include <iostream>
#include "Node.h"
#include "Stack.h"

template <typename T>
class LinkedList
{
public:
    Node<T> *head;

    LinkedList();
    ~LinkedList();

    void insertAtHead(T data);
    void insertAtTail(T data);
    void insertAtPosition(T data, int pos);
    void deleteAtHead();
    void deleteAtTail();
    void deleteAtPosition(int pos);
    void reverse();
    void display();
};

template <typename T>
LinkedList<T>::LinkedList()
{
    head = nullptr;
}

template <typename T>
LinkedList<T>::~LinkedList()
{
    Node<T> *current = head;
    while (current != nullptr)
    {
        Node<T> *nextNode = current->next;
        delete current;
        current = nextNode;
    }
}

template <typename T>
void LinkedList<T>::insertAtHead(T data)
{
    Node<T> *newNode = new Node<T>(data);
    newNode->next = head;
    head = newNode;
}

template <typename T>
void LinkedList<T>::insertAtTail(T data)
{
    Node<T> *newNode = new Node<T>(data);
    if (head == nullptr)
    {
        head = newNode;
        return;
    }
    Node<T> *temp = head;
    while (temp->next != nullptr)
    {
        temp = temp->next;
    }
    temp->next = newNode;
}

template <typename T>
void LinkedList<T>::insertAtPosition(T data, int pos)
{
    if (pos == 0)
    {
        insertAtHead(data);
        return;
    }
    Node<T> *newNode = new Node<T>(data);
    Node<T> *temp = head;
    for (int i = 0; temp != nullptr && i < pos - 1; i++)
    {
        temp = temp->next;
    }
    if (temp == nullptr)
        return;
    newNode->next = temp->next;
    temp->next = newNode;
}

template <typename T>
void LinkedList<T>::deleteAtHead()
{
    if (head == nullptr)
        return;
    Node<T> *temp = head;
    head = head->next;
    delete temp;
}

template <typename T>
void LinkedList<T>::deleteAtTail()
{
    if (head == nullptr)
        return;
    if (head->next == nullptr)
    {
        delete head;
        head = nullptr;
        return;
    }
    Node<T> *temp = head;
    while (temp->next->next != nullptr)
    {
        temp = temp->next;
    }
    delete temp->next;
    temp->next = nullptr;
}

template <typename T>
void LinkedList<T>::deleteAtPosition(int pos)
{
    if (head == nullptr)
        return;
    if (pos == 0)
    {
        deleteAtHead();
        return;
    }
    Node<T> *temp = head;
    for (int i = 0; temp->next != nullptr && i < pos - 1; i++)
    {
        temp = temp->next;
    }
    if (temp->next == nullptr)
        return;
    Node<T> *toDelete = temp->next;
    temp->next = temp->next->next;
    delete toDelete;
}

template <typename T>
void LinkedList<T>::reverse()
{
    Stack<T> stack;
    Node<T> *temp = head;
    while (temp != nullptr)
    {
        stack.push(temp->data);
        temp = temp->next;
    }
    temp = head;
    while (temp != nullptr)
    {
        temp->data = stack.peek();
        stack.pop();
        temp = temp->next;
    }
}

template <typename T>
void LinkedList<T>::display()
{
    Node<T> *temp = head;
    while (temp != nullptr)
    {
        std::cout << temp->data << " -> ";
        temp = temp->next;
    }
    std::cout << "NULL" << std::endl;
}

#endif
