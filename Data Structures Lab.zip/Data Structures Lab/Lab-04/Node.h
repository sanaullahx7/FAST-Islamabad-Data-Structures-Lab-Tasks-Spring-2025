//Muhammad Mudassir
//I23-2562
//DS-4A
//Lab-04

#ifndef NODE_H
#define NODE_H

template <typename T>
class Node
{
public:
    T data;
    Node *next;

    Node(T value)
    {
        data = value;
        next = nullptr;
    }
};

#endif