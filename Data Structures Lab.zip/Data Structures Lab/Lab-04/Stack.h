//Muhammad Mudassir
//I23-2562
//DS-4A
//Lab-04

#ifndef STACK_H
#define STACK_H

#include <iostream>
#include "Node.h"
using namespace std;

template <typename T>
class Stack
{
private:
    Node<T> *top;

public:
    Stack();
    ~Stack();

    void push(T value);
    void pop();
    T peek();
    bool isEmpty();
    void display();
};

template <typename T>
Stack<T>::Stack()
{
    top = nullptr;
}

template <typename T>
Stack<T>::~Stack()
{
    while (!isEmpty())
    {
        pop();
    }
}

template <typename T>
void Stack<T>::push(T value)
{
    Node<T> *newNode = new Node<T>(value);
    newNode->next = top;
    top = newNode;
}

template <typename T>
void Stack<T>::pop()
{
    if (isEmpty())
    {
        cout << "Stack Underflow\n";
        return;
    }
    Node<T> *temp = top;
    top = top->next;
    delete temp;
}

template <typename T>
T Stack<T>::peek()
{
    if (isEmpty())
    {
        cout << "Stack is empty\n";
        return T();
    }
    return top->data;
}

template <typename T>
bool Stack<T>::isEmpty()
{
    return top == nullptr;
}

template <typename T>
void Stack<T>::display()
{
    if (isEmpty())
    {
        cout << "Stack is empty\n";
        return;
    }
    Node<T> *temp = top;
    cout << "Stack: ";
    while (temp)
    {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}

#endif
