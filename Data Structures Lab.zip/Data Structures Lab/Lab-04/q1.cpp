//Muhammad Mudassir
//I23-2562
//DS-4A
//Lab-04

#include <iostream>
#include "LinkedList.h"
using namespace std;

int main()
{
    LinkedList<int> list;

    list.insertAtTail(1);
    list.insertAtTail(2);
    list.insertAtTail(3);
    list.insertAtTail(4);
    list.insertAtTail(5);
    list.insertAtTail(6);
    list.insertAtTail(7);
    list.insertAtTail(8);

    list.display();
    cout << endl;
    list.reverse();
    cout << endl;
    list.display();
}
