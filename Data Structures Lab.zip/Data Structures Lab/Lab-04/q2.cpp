//Muhammad Mudassir
//I23-2562
//DS-4A
//Lab-04

#include <iostream>
#include "Stack.h"
using namespace std;

bool isBalanced(string brackets)
{
    Stack<char> s;

    int i = 0;
    while (brackets[i] != '\0')
    {
        char ch = brackets[i];
        if (ch == '(' || ch == '{' || ch == '[')
        {
            s.push(ch);
            i++;
        }
        else
        {
            if (s.isEmpty())
                return false;

            char top = s.peek();
            s.pop();

            if ((ch == ')' && top != '(') ||
                (ch == '}' && top != '{') ||
                (ch == ']' && top != '['))
            {
                return false;
            }
            i++;
        }
    }

    return s.isEmpty();
}

int main()
{
    string str1 = "{[()]}";
    string str2 = "{[(])}";
    string str3 = "{{[[(())]]}}";
    string str4 = "((())";

    cout << "{[()]}       ->  " << (isBalanced(str1) ? "Balanced" : "Not Balanced") << endl;
    cout << "{[(])}       ->  " << (isBalanced(str2) ? "Balanced" : "Not Balanced") << endl;
    cout << "{{[[(())]]}} ->  " << (isBalanced(str3) ? "Balanced" : "Not Balanced") << endl;
    cout << "((())        ->  " << (isBalanced(str4) ? "Balanced" : "Not Balanced") << endl;

    return 0;
}
