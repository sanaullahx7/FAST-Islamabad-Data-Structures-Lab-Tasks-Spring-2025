//Muhammad Mudassir
//I23-2562
//DS-4A
//Lab-04

#include <iostream>
#include "Stack.h"
using namespace std;

void convertToBinary(int decimalNumber)
{
    Stack<int> stack;

    if (decimalNumber == 0)
    {
        cout << "Binary: 0" << endl;
        return;
    }

    while (decimalNumber > 0)
    {
        int remainder = decimalNumber % 2;
        stack.push(remainder);
        decimalNumber /= 2;
    }
    cout << endl;

    cout << "Binary equivalent : ";
    while (!stack.isEmpty())
    {
        cout << stack.peek();
        stack.pop();
    }
    cout << endl;
}

int main()
{
    int decimalNumber;
    cout << "Enter a decimal number: ";
    cin >> decimalNumber;

    convertToBinary(decimalNumber);
    return 0;
}
