#include <iostream>
#include "stack.h"

using namespace std;

bool isOperand(char c)
{
    char list[] = {'+', '-', '*', '/', '%', '(', ')', '[', ']', '{', '}'};
    for (int i = 0; i < 11; i++)
    {
        if (c == list[i])
            return false;
    }
    return true;
}

int precedence(char c)
{
    if (c == '+' || c == '-')
        return 1;
    if (c == '*' || c == '/' || c == '%')
        return 2;
    return 0;
}

string reverse(string str)
{
    stack s;
    string result = "";
    int i = 0;
    while (str[i] != '\0')
    {
        s.push(str[i]);
        i++;
    }
    i = 0;
    while (!s.isEmpty())
    {
        result += s.pop();
    }
    while (result[i] != '\0')
    {
        if (result[i] == '(')
            result[i] = ')';
        else if (result[i] == ')')
            result[i] = '(';

        i++;
    }
    return result;
}

string infixToPostfinx(string inFix)
{
    int size = inFix.length();
    stack s1;
    string postFix;

    for (int i = 0; i < size; i++)
    {
        char c = inFix[i];

        if (isOperand(c))
        {
            postFix += c;
        }
        else if (c == '(' || c == '[' || c == '{')
        {
            s1.push(c);
        }
        else if (c == ')' || c == ']' || c == '}')
        {
            while (!s1.isEmpty() && s1.peek() != '(' && s1.peek() != '[' && s1.peek() != '{')
            {
                postFix += s1.pop();
            }
            s1.pop();
        }
        else
        {
            while (!s1.isEmpty() && precedence(s1.peek()) >= precedence(c))
            {
                postFix += s1.pop();
            }
            s1.push(c);
        }
    }

    while (!s1.isEmpty())
    {
        postFix += s1.pop();
    }
    return postFix;
}

int main()
{
    string inFix;
    string postFix;
    string preFix;

    cout << "Enter the inFix Expression : ";
    cin >> inFix;

    inFix = reverse(inFix);
    postFix = infixToPostfinx(inFix);
    preFix = reverse(postFix);

    cout << "The PreFix Expression is as follows : " << preFix;
}