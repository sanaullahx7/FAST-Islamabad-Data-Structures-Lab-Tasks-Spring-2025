#include <iostream>
#include "stack.h"
using namespace std;

bool isOperand(char c)
{
    char list[] = {'+', '-', '*', '/', '%', '(', ')', '[', ']', '{', '}'};
    for (int i = 0; i < 11; i++)
    {
        if (c == list[i])
            return false;
    }
    return true;
}

int resolve(string postfix)
{
    stack s;
    int i = 0;
    while (postfix[i] != '\0')
    {
        char c = postfix[i];
        if (isOperand(c))
        {
            s.push(c); 
        }
        else
        { 
            int operand2 = s.pop() - '0';
            int operand1 = s.pop() - '0';

            switch (c)
            {
            case '+':
                s.push(operand1 + operand2 + '0');
                break;
            case '-':
                s.push(operand1 - operand2 + '0');
                break;
            case '*':
                s.push(operand1 * operand2 + '0');
                break;
            case '/':
                s.push(operand1 / operand2 + '0');
                break;
            }
        }
        i++;
    }
    return s.peek() - '0';
}

int main()
{
    string postFix;

    cout<<"Enter PostFix Expression : ";
    cin>>postFix;

    cout<<"The Final Result is : "<< resolve(postFix);
}