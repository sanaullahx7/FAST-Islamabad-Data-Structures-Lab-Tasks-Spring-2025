#include <iostream>
#include "stack.h"

using namespace std;

bool isOperand(char c)
{
    char list[] = {'+', '-', '*', '/', '%', '(', ')', '[', ']', '{', '}'};
    for (int i = 0; i < 11; i++)
    {
        if (c == list[i])
            return false;
    }
    return true;
}

int precedence(char c)
{
    if (c == '+' || c == '-')
        return 1;
    if (c == '*' || c == '/' || c == '%')
        return 2;
    return 0;
}

string infixToPostfinx(string inFix)
{
    int size = inFix.length();
    stack s1;
    string postFix;

    for (int i = 0; i < size; i++)
    {
        char c = inFix[i];

        if (isOperand(c))
        {
            postFix += c;
        }
        else if (c == '(' || c == '[' || c == '{')
        {
            s1.push(c);
        }
        else if (c == ')' || c == ']' || c == '}')
        {
            while (!s1.isEmpty() && s1.peek() != '(' && s1.peek() != '[' && s1.peek() != '{')
            {
                postFix += s1.pop();
            }
            s1.pop();
        }
        else
        {
            while (!s1.isEmpty() && precedence(s1.peek()) >= precedence(c))
            {
                postFix += s1.pop();
            }
            s1.push(c);
        }
    }

    while (!s1.isEmpty())
    {
        postFix += s1.pop();
    }
    return postFix;
}

int main()
{
    string inFix;

    cout << "Enter the Infix Expression : ";
    cin >> inFix;

    cout << "Postfix Expression: " << infixToPostfinx(inFix) << endl;
    return 0;
}
