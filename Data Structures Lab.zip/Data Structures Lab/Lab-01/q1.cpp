#include <iostream>
using namespace std;

void deleteDuplicate(int *arr, int &size)
{
    int newSize = 0;

    for (int i = 0; i < size; i++)
    {
        if (i == 0 || arr[i] != arr[i - 1])
        {
            arr[newSize] = arr[i];
            newSize++;
        }
    }

    size = newSize;
}

void Print(int *arr, int size)
{
    for (int i = 0; i < size; i++)
    {
        cout << arr[i] << " ";
    }
    cout << endl;
}

int main()
{
    int size = 10;
    int *arr = new int[size];

    cout << "Enter 10 sorted elements: ";
    for (int i = 0; i < size; i++)
    {
        cin >> arr[i];
    }

    cout << "Original Array: ";
    Print(arr, size);

    deleteDuplicate(arr, size);

    cout << "Array after removing duplicates: ";
    Print(arr, size);

    delete[] arr; 
}
