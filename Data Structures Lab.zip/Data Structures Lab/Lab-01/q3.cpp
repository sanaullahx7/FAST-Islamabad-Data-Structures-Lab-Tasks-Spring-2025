#include <iostream>
using namespace std;

void smallest_and_largest(int *arr, int size)
{
    int smallest = *(arr), largest = *(arr);
    for (int i = 0; i < size; i++)
    {
        if (smallest > *(arr + i))
        {
            smallest = *(arr + i);
        }

        if (largest < *(arr + i))
        {
            largest = *(arr + i);
        }
    }
    cout << "The Smallest Number is : " << smallest << endl;
    cout << "The Largest Number is : " << largest << endl;
}

void populate(int *arr, int size)
{
    for (int i = 0; i < size; i++)
    {
        cout << "Enter the " << i + 1 << " Element : ";
        cin >> *(arr + i);
    }
}

void print(int *arr, int size)
{
    for (int i = 0; i < size; i++)
    {
        cout << *(arr + i) << " ";
    }
    cout<<endl<<endl;
}

void Double_the_size(int *&arr, int &size)
{
    int iterator = size;
    size = size * 2;

    int *arr2 = new int(size);

    for (int i = 0; i < iterator; i++)
    {
        *(arr2 + i) = *(arr + i);
    }

    for (int i = iterator; i < size; i++)
    {
        cout << "Enter the " << i + 1 << " Element : ";
        cin >> *(arr2 + i);
    }
    
    delete[] arr;
    arr = arr2;
    delete [] arr;
}


int main()
{
    int size;
    cout << "Enter The size of Array : ";
    cin >> size;

    int *arr = new int(size);

    while (true)
    {

        char c;
        cout << "1.  Populate.\n";
        cout << "2.  Find Max, Min.\n";
        cout << "3.  Print.\n";
        cout << "4.  Double The Size.\n";
        cout << "5.  Exit.\n\n";

        cout << "Enter Choice : ";
        cin >> c;

        switch (c)
        {
        case '1':
            populate(arr, size);
            break;

        case '2':
            smallest_and_largest(arr, size);
            break;

        case '3':
            print(arr, size);
            break;

        case '4':
            Double_the_size(arr, size);
            break;

        case '5':
            delete[] arr;
            return 0;
            break;
        default:
            break;
        }
    }
}