#include<iostream>
using namespace std;

void smallest_and_largest(int* arr, int size){
    int smallest = *(arr), largest = *(arr);
    for(int i=0; i<size; i++){
        if(smallest > *(arr + i)){
            smallest = *(arr + i);
        }

        if(largest < *(arr + i)){
            largest = *(arr + i);
        }
    }
        cout<<"The Smallest Number is : "<<smallest<<endl;
        cout<<"The Largest Number is : "<<largest<<endl;
}

void populate(int* arr, int size){
     for(int i=0; i<size; i++){
        cout<<"Enter the "<<i+1<<" Element : ";
        cin>>*(arr+i);        
     }
}

int main(){
    int size;

    cout<<"Enter the size : ";
    cin>>size;

    int* arr = new int(size);

    populate(arr, size);
    smallest_and_largest(arr, size);
}