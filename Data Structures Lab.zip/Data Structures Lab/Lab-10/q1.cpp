#include <iostream>
#include <queue> 
using namespace std;

class Node
{
public:
    int data;
    Node *left;
    Node *right;

    Node(int data = 0)
    {
        this->data = data;
        this->left = nullptr;
        this->right = nullptr;
    }
};

class BST
{
public:
    Node *root;

    BST()
    {
        this->root = nullptr;
    }

    
    Node *insert(Node *node, int val)
    {
        if (node == nullptr)
        {
            return new Node(val);
        }
        if (val < node->data)
        {
            node->left = insert(node->left, val);
        }
        else if (val > node->data)
        {
            node->right = insert(node->right, val);
        }
        return node;
    }

    void insert(int val)
    {
        root = insert(root, val);
    }

    Node *findMin(Node *node)
    {
        while (node && node->left != nullptr)
            node = node->left;
        return node;
    }

    Node *deleteNode(Node *node, int val)
    {
        if (node == nullptr)
            return node;

        if (val < node->data)
        {
            node->left = deleteNode(node->left, val);
        }
        else if (val > node->data)
        {
            node->right = deleteNode(node->right, val);
        }
        else
        {
            if (node->left == nullptr)
            {
                Node *temp = node->right;
                delete node;
                return temp;
            }
            else if (node->right == nullptr)
            {
                Node *temp = node->left;
                delete node;
                return temp;
            }
            Node *temp = findMin(node->right);
            node->data = temp->data;
            node->right = deleteNode(node->right, temp->data);
        }
        return node;
    }

    void deleteNode(int val)
    {
        root = deleteNode(root, val);
    }

    void PrintBFS()
    {
        if (root == nullptr)
        {
            cout << "Tree is empty.\n";
            return;
        }

        queue<Node *> q;
        q.push(root);

        while (!q.empty())
        {
            Node *current = q.front();
            q.pop();
            cout << current->data << " ";

            if (current->left != nullptr)
                q.push(current->left);
            if (current->right != nullptr)
                q.push(current->right);
        }
        cout << endl;
    }

    void DisplayTree(Node *node)
    {
        if (node == nullptr)
            return;
        DisplayTree(node->left);
        cout << node->data << " ";
        DisplayTree(node->right);
    }

    void DisplayTree()
    {
        if (root == nullptr)
        {
            cout << "Tree is empty.\n";
            return;
        }
        DisplayTree(root);
        cout << endl;
    }
};

int main()
{
    BST tree;

    tree.insert(50);
    tree.insert(30);
    tree.insert(70);
    tree.insert(20);
    tree.insert(40);
    tree.insert(60);
    tree.insert(80);

    cout << "BFS Traversal (Level Order): ";
    tree.PrintBFS();

    cout << "Inorder Traversal (Sorted): ";
    tree.DisplayTree();

    cout << "Deleting 20\n";
    tree.deleteNode(20);

    cout << "Inorder after deletion: ";
    tree.DisplayTree();

    cout << "Deleting 30\n";
    tree.deleteNode(30);

    cout << "Inorder after deletion: ";
    tree.DisplayTree();

    cout << "Deleting 50\n";
    tree.deleteNode(50);

    cout << "Inorder after deletion: ";
    tree.DisplayTree();

    return 0;
}
