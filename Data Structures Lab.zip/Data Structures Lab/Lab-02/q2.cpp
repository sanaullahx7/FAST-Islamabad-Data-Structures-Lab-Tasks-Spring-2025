#include <iostream>
using namespace std;

class ArrayList {
private:
    int* arr;
    int size;
    int count;

public:
    
    ArrayList(int n = 10) {
        this->size = n;
        this->arr = new int[n]; 
        this->count = 0;
    }

 
    ~ArrayList() {
        delete[] arr;
    }

   
    int getSize() {
        return this->size;
    }

    
    void Resize() {
        int newSize = this->size * 2;
        int* arr2 = new int[newSize];

        for (int i = 0; i < this->size; i++) {
            arr2[i] = this->arr[i];
        }

        delete[] this->arr;  
        this->arr = arr2;    
        this->size = newSize;
    }

   
    void Add(int num) {
        if (this->count == this->size) {
            Resize(); 
        }
        this->arr[this->count++] = num;
    }

   
    void Remove(int index) {
        if (index < 0 || index >= this->count) {
            cout << "Invalid index!\n";
            return;
        }

        for (int i = index; i < this->count - 1; i++) {
            this->arr[i] = this->arr[i + 1];
        }
        this->count--;
    }

 
    void Print() {
        for (int i = 0; i < this->count; i++) {
            cout << this->arr[i] << " ";
        }
        cout << "\n";
    }
};


int main() {
    ArrayList arraylist(5); 


    arraylist.Add(1);
    arraylist.Add(2);
    arraylist.Add(3);
    arraylist.Add(4);
    arraylist.Add(5);

    cout << "Initial Array: ";
    arraylist.Print();
    cout << "Size: " << arraylist.getSize() << "\n\n";

    arraylist.Add(6);
    arraylist.Add(7);
    arraylist.Add(8);
    arraylist.Add(9);
    arraylist.Add(10);
    arraylist.Add(11); 

    cout << "After Adding More Elements: ";
    arraylist.Print();
    cout << "Size: " << arraylist.getSize() << "\n\n";


    arraylist.Remove(3);  
    cout << "After Removing index 3: ";
    arraylist.Print();
    
    return 0;
}
