#include<iostream>
using namespace std;

void input(int* arr, int n=10){
    for(int i=0; i<n; i++){
        cout<<"Enter the "<<i+1<<" Element : ";
        cin>>*(arr+i);
    }
    cout<<"\n\n\n";
}

int main(){
    int* arr1 = new int(10);
    int* arr2 = new int(10);
    int* arr3 = new int(10); 

    
    cout<<"For Array 1 : \n";
    input(arr1);
    cout<<"For Array 2 : \n";
    input(arr2);

    int k = 0;
    for(int i=0; i<10; i++){
        for(int j=0; j<10; j++){
            if(*(arr1 + i) == *(arr2 + j)){
                *(arr3 + k++) = *(arr1 + i);
                break;
            }
        }
    }

    cout<<"The Unique Common Elements in the rray : \n";

    for(int i=0; i<k; i++){
        cout<<*(arr3 + i)<<" ";
    }    
}