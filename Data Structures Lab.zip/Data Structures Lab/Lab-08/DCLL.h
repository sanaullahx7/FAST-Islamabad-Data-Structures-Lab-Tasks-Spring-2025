#ifndef DCLL_H
#define DCLL_H

#include <iostream>

class Node {
public:
    int key, value;
    Node* prev;
    Node* next;
    
    Node(int k, int v) : key(k), value(v), prev(nullptr), next(nullptr) {}
};

class DCLL {
private:
    int capacity;
    int size;
    Node* head;
    
    void removeNode(Node* node);
    void insertAtEnd(Node* node);

public:
    DCLL(int cap);
    ~DCLL();
    void insert(int key, int value);
    int access(int key);
    void display();
};

DCLL::DCLL(int cap) : capacity(cap), size(0), head(nullptr) {}

DCLL::~DCLL() {
    while (head) {
        removeNode(head);
    }
}

void DCLL::removeNode(Node* node) {
    if (!node) return;
    
    if (node->next == node) {
        delete node;
        head = nullptr;
        size--;
        return;
    }
    
    node->prev->next = node->next;
    node->next->prev = node->prev;
    
    if (head == node)
        head = node->next;
    
    delete node;
    size--;
}

void DCLL::insertAtEnd(Node* node) {
    if (!head) {
        head = node;
        head->next = head;
        head->prev = head;
    } else {
        Node* tail = head->prev;
        tail->next = node;
        node->prev = tail;
        node->next = head;
        head->prev = node;
    }
    size++;
}

void DCLL::insert(int key, int value) {
    Node* newNode = new Node(key, value);
    if (size == capacity) {
        removeNode(head);  
    }
    insertAtEnd(newNode);
}

int DCLL::access(int key) {
    if (!head) return -1;
    Node* temp = head;
    do {
        if (temp->key == key) {
            int val = temp->value;
            removeNode(temp);
            insertAtEnd(new Node(key, val));
            return val;
        }
        temp = temp->next;
    } while (temp != head);
    return -1;
}

void DCLL::display() {
    if (!head) {
        std::cout << "Cache is empty" << std::endl;
        return;
    }
    Node* temp = head;
    do {
        std::cout << "(" << temp->key << ", " << temp->value << ") -> ";
        temp = temp->next;
    } while (temp != head);
    std::cout << "(Back to head)" << std::endl;
}

#endif
