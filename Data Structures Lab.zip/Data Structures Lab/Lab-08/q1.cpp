#include<iostream>
#include "SCLL.h"

using namespace std;

int josephus(int n, int k) {
    SinglyCircular list;
    for (int i = 1; i <= n; i++) {
        list.insert(i);
    }
    
    Node *curr = list.tail->next, *prev = list.tail;
    while (curr->next != curr) {
        for (int count = 1; count < k; count++) {
            prev = curr;
            curr = curr->next;
        }
        prev->next = curr->next;
        if (curr == list.tail) list.tail = prev;
        delete curr;
        curr = prev->next;
    }
    int survivor = curr->data;
    delete curr;
    list.tail = nullptr;
    return survivor;
}

int main() {
    int n, k;
    cout << "Enter number of people (N): ";
    cin >> n;
    cout << "Enter step count (K): ";
    cin >> k;
    
    int survivor = josephus(n, k);
    cout << "The survivor is at position: " << survivor << endl;
    
    return 0;
}