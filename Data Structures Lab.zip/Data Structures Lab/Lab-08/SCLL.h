#ifndef SCLL
#define SCLL

#include<iostream>
using namespace std;

class Node{
    public:
      int data;
      Node* next;

      Node(int data = 0){
        this -> data = data;
        this -> next = nullptr;
      }
};

class SinglyCircular{  // Singly circular linked list
    public:
      Node* tail;

      SinglyCircular(){
        this -> tail = nullptr;
      }

      void insert(int data) {
          Node* newNode = new Node(data);
          if (!tail) {
              tail = newNode;
              tail->next = tail;
          } else {
              newNode->next = tail->next;
              tail->next = newNode;
              tail = newNode;
          }
      }

      void deleteNode(int key) {
          if (!tail) return;
          Node *curr = tail->next, *prev = tail;
          do {
              if (curr->data == key) {
                  if (curr == tail) {
                      if (tail == tail->next) tail = nullptr;
                      else {
                          prev->next = tail->next;
                          tail = prev;
                      }
                  } else {
                      prev->next = curr->next;
                  }
                  delete curr;
                  return;
              }
              prev = curr;
              curr = curr->next;
          } while (curr != tail->next);
      }

      void display() {
          if (!tail) {
              cout << "List is empty!\n";
              return;
          }
          Node* temp = tail->next;
          do {
              cout << temp->data << " -> ";
              temp = temp->next;
          } while (temp != tail->next);
          cout << "(Head)\n";
      }

      bool search(int key) {
          if (!tail) return false;
          Node* temp = tail->next;
          do {
              if (temp->data == key) return true;
              temp = temp->next;
          } while (temp != tail->next);
          return false;
      }
};



#endif