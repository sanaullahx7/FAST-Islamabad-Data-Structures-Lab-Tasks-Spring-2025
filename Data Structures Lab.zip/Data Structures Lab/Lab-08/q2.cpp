#include "DCLL.h"

int main() {
    DCLL cache(3); 

    cache.insert(1, 10);
    cache.insert(2, 20);
    cache.insert(3, 30);
    cache.display();  

    std::cout << "Accessing key 2: " << cache.access(2) << std::endl;  
    cache.display();  

    cache.insert(4, 40); 
    cache.display();

    std::cout << "Accessing key 3: " << cache.access(3) << std::endl;
    cache.display();  

    cache.insert(5, 50); 
    cache.display();

    return 0;
}
