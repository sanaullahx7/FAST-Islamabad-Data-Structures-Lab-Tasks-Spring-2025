#include <iostream>
#include <queue>
#include <iomanip>
using namespace std;

class Node
{
public:
    int key, height;
    Node *left;
    Node *right;
    Node(int val) {
        this -> key = val;
        this -> height = 1;
        this -> left = this -> right = nullptr;
    }
};

class AVLTree
{
private:
    Node *root = nullptr;

    int leftRotations = 0;
    int rightRotations = 0;
    int leftRightRotations = 0;
    int rightLeftRotations = 0;

    int height(Node *n)
    {
        return n ? n->height : 0;
    }

    int getBalance(Node *n)
    {
        return n ? height(n->left) - height(n->right) : 0;
    }

    void updateHeight(Node *n)
    {
        n->height = 1 + max(height(n->left), height(n->right));
    }

    Node *rotateRight(Node *y)
    {
        Node *x = y->left;
        Node *T2 = x->right;

        x->right = y;
        y->left = T2;

        updateHeight(y);
        updateHeight(x);

        rightRotations++;
        return x;
    }

    Node *rotateLeft(Node *x)
    {
        Node *y = x->right;
        Node *T2 = y->left;

        y->left = x;
        x->right = T2;

        updateHeight(x);
        updateHeight(y);

        leftRotations++;
        return y;
    }

    Node *balance(Node *node)
    {
        updateHeight(node);
        int balanceFactor = getBalance(node);

        if (balanceFactor > 1)
        {
            if (getBalance(node->left) >= 0)
            {
                return rotateRight(node); 
            }
            else
            {
                node->left = rotateLeft(node->left); 
                leftRightRotations++;
                return rotateRight(node); 
            }
        }
        else if (balanceFactor < -1)
        {
            if (getBalance(node->right) <= 0)
            {
                return rotateLeft(node); 
            }
            else
            {
                node->right = rotateRight(node->right);
                rightLeftRotations++;
                return rotateLeft(node); 
            }
        }
        return node;
    }

    Node *insert(Node *node, int key)
    {
        if (!node)
            return new Node(key);
        if (key < node->key)
            node->left = insert(node->left, key);
        else if (key > node->key)
            node->right = insert(node->right, key);
        else
            return node; 

        return balance(node);
    }

    Node *findMin(Node *node)
    {
        return node->left ? findMin(node->left) : node;
    }

    Node *deleteNode(Node *node, int key)
    {
        if (!node)
            return node;

        if (key < node->key)
            node->left = deleteNode(node->left, key);
        else if (key > node->key)
            node->right = deleteNode(node->right, key);
        else
        {
            if (!node->left || !node->right)
            {
                Node *temp = node->left ? node->left : node->right;
                delete node;
                return temp;
            }
            else
            {
                Node *temp = findMin(node->right);
                node->key = temp->key;
                node->right = deleteNode(node->right, temp->key);
            }
        }

        return balance(node);
    }

    void inOrderTraversal(Node *node)
    {
        if (!node)
            return;
        inOrderTraversal(node->left);
        cout << node->key << " ";
        inOrderTraversal(node->right);
    }

    void display(Node *node, string indent = "", bool last = true)
    {
        if (node)
        {
            cout << indent;
            if (last)
            {
                cout << "R----";
                indent += "     ";
            }
            else
            {
                cout << "L----";
                indent += "|    ";
            }
            cout << node->key << endl;
            display(node->left, indent, false);
            display(node->right, indent, true);
        }
    }

public:
    void insert(int key)
    {
        root = insert(root, key);
    }

    void deleteNode(int key)
    {
        root = deleteNode(root, key);
    }

    void inOrderTraversal()
    {
        inOrderTraversal(root);
        cout << endl;
    }

    void levelOrderTraversal()
    {
        if (!root)
            return;
        queue<Node *> q;
        q.push(root);
        while (!q.empty())
        {
            Node *node = q.front();
            q.pop();
            cout << node->key << " ";
            if (node->left)
                q.push(node->left);
            if (node->right)
                q.push(node->right);
        }
        cout << endl;
    }

    void display()
    {
        display(root);
    }

    void printRotationCounts()
    {
        cout << "Left Rotations: " << leftRotations << endl;
        cout << "Right Rotations: " << rightRotations << endl;
        cout << "Left-Right Rotations: " << leftRightRotations << endl;
        cout << "Right-Left Rotations: " << rightLeftRotations << endl;
    }
};

int main()
{
    AVLTree tree;
    tree.insert(30);
    tree.insert(20);
    tree.insert(40);
    tree.insert(10);
    tree.insert(25);
    tree.insert(35);
    tree.insert(50);
    tree.insert(5);

    cout << "In-order Traversal: ";
    tree.inOrderTraversal();

    cout << "Level-order Traversal: ";
    tree.levelOrderTraversal();

    cout << "Tree Structure:\n";
    tree.display();

    tree.deleteNode(40);
    cout << "\nAfter deleting 40:\n";
    tree.display();

    tree.printRotationCounts();

    return 0;
}
