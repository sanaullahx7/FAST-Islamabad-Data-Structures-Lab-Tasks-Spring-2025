#ifndef TASK3
#define TASK3

#include <iostream>
using namespace std;

class Node
{
public:
    int jobNo;
    int pages;
    Node *next;
    static int count;

    Node(int pages = 1)
    {
        this->pages = pages;
        this->jobNo = count++;
        this->next = nullptr;
    }
};


class PrintQueue
{
public:
    Node *front;
    Node *rear;

    PrintQueue()
    {
        this->front = nullptr;
        this->rear = nullptr;
    }

    ~PrintQueue()
    {
        while (!isEmpty())
        {
            Process();
        }
    }

    void addJob(int pages = 1)
    {
        Node *newNode = new Node(pages);
        cout << "Adding Job " << newNode->jobNo << " (" << newNode->pages << " pages)" << endl;

        if (front == nullptr)
        {
            front = rear = newNode;
            return;
        }

        rear->next = newNode;
        rear = newNode;
    }

    void Process()
    {
        if (isEmpty())
        {
            cout << "Queue is Empty" << endl;
            return;
        }

        Node *temp = front;
        cout << "Processing Job " << temp->jobNo << " (" << temp->pages << " pages)" << endl;

        front = front->next;
        if (front == nullptr)
        {
            rear = nullptr;
        }

        delete temp;
    }

    void DisplayQueue()
    {
        if (isEmpty())
        {
            cout << "Queue is Empty" << endl;
            return;
        }

        Node *temp = front;
        while (temp)
        {
            cout << "-> Job " << temp->jobNo << " (" << temp->pages << " pages)" << endl;
            temp = temp->next;
        }
    }

    bool isEmpty()
    {
        return front == nullptr;
    }
};

#endif
