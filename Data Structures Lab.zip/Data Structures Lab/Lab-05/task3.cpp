#include<iostream>
#include "task3.h"

using namespace std;
int Node::count = 1;

int main() {
    PrintQueue queue;

    cout << "Adding print jobs ..." << endl;
    queue.addJob(5);
    queue.addJob(10);
    queue.addJob(3);
    queue.addJob(7);

    cout << "\nCurrent Print Queue:" << endl;
    queue.DisplayQueue();

    cout << "\nProcessing print jobs..." << endl;
    while (!queue.isEmpty()) {
        queue.Process();
    }

    cout << "\nAttempting to process a job from an empty queue:" << endl;
    queue.Process();

    return 0;
}