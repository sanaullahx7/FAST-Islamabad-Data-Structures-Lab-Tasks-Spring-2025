#ifndef TASK2
#define TASK2

#include <iostream>
using namespace std;
class Node
{
public:
    int data;
    Node *next;

    Node(int data = 0)
    {
        this->data = data;
        this->next = nullptr;
    }
};

class Queue
{
public:
    Node *front;
    Node *rear;

    void Enqueue(int data = 0)
    {
        Node *newNode = new Node(data);
        if (front == nullptr || rear == nullptr)
        {
            this->front = newNode;
            this->rear = newNode;
            return;
        }
        rear->next = newNode;
        rear = newNode;
    }

    int Dequeue()
    {
        if (front == nullptr || rear == nullptr)
        {
            cout << "Empty Queue";
            return -1;
        }
        Node *newNode = front;
        front = front->next;

        int data = newNode->data;
        delete newNode;
        return data;
    }

    int top()
    {
        if (!(front == nullptr || rear == nullptr))
            return front->data;

        cout << "Queue is Empty \n";
        return -1;
    }

    bool isEmpty()
    {
        if (front == nullptr || rear == nullptr)
            return true;

        return false;
    }
};
#endif