#include<iostream>
#include "task2.h"

using namespace std;

int main()
{
    Queue queue;
    
    cout << "Enqueueing elements: 10, 20, 30, 40, 50" << endl;
    queue.Enqueue(10);
    queue.Enqueue(20);
    queue.Enqueue(30);
    queue.Enqueue(40);
    queue.Enqueue(50);
    
    cout << "Front element: " << queue.top() << endl;
    
    cout << "Dequeueing elements: " << endl;
    while (!queue.isEmpty())
    {
        cout << queue.Dequeue() << " ";
    }
    cout << endl;
    
    cout << "Trying to get front element of empty queue: " << queue.top() << endl;
    
    return 0;
}