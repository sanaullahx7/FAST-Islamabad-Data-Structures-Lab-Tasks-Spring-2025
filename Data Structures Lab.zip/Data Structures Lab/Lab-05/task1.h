#ifndef TASK1
#define TASK1

#include <iostream>
using namespace std;

class Queue {
    int front;
    int rear;
    int size;
    int capacity;
    int* arr;

public:
    Queue(int capacity = 10) {
        this->capacity = capacity;
        arr = new int[capacity];
        size = 0;
        front = 0;
        rear = -1;
    }

    ~Queue() {
        delete[] arr;
    }

    void Enqueue(int x) {
        if (isFull()) {
            cout << "Queue is Full" << endl;
            return;
        }

        rear = (rear + 1) % capacity;
        arr[rear] = x;
        size++;
    }

    int Dequeue() {
        if (isEmpty()) {
            cout << "Queue is Empty" << endl;
            return -1;
        }

        int data = arr[front];
        front = (front + 1) % capacity;
        size--;

        return data;
    }

    int Front() {
        if (isEmpty()) {
            cout << "Queue is Empty" << endl;
            return -1;
        }
        return arr[front];
    }

    bool isEmpty() {
        return size == 0;
    }

    bool isFull() {
        return size == capacity;
    }
};

#endif
