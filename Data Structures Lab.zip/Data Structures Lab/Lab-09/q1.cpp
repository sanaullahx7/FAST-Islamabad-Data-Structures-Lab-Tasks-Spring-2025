#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node *left;
    Node *right;

    Node(int data)
    {
        this->data = data;
        this->left = nullptr;
        this->right = nullptr;
    }
};

class BST
{
public:
    Node *root;

    BST()
    {
        root = nullptr;
    }

    Node *insert(Node *node, int value)
    {
        if (node == nullptr)
        {
            return new Node(value);
        }

        if (value < node->data)
        {
            node->left = insert(node->left, value);
        }
        else if (value > node->data)
        {
            node->right = insert(node->right, value);
        }

        return node;
    }

    void insert(int value)
    {
        root = insert(root, value);
    }

    void inorder(Node *node)
    {
        if (node != nullptr)
        {
            inorder(node->left);
            cout << node->data << " ";
            inorder(node->right);
        }
    }

    void inorder()
    {
        cout << "Inorder: ";
        inorder(root);
        cout << endl;
    }

    void preorder(Node *node)
    {
        if (node != nullptr)
        {
            cout << node->data << " ";
            preorder(node->left);
            preorder(node->right);
        }
    }

    void preorder()
    {
        cout << "Preorder: ";
        preorder(root);
        cout << endl;
    }

    void postorder(Node *node)
    {
        if (node != nullptr)
        {
            postorder(node->left);
            postorder(node->right);
            cout << node->data << " ";
        }
    }

    void postorder()
    {
        cout << "Postorder: ";
        postorder(root);
        cout << endl;
    }
};

int main()
{
    BST tree;
    tree.insert(50);
    tree.insert(30);
    tree.insert(70);
    tree.insert(20);
    tree.insert(60);
    tree.insert(80);

    tree.inorder();
    tree.preorder();
    tree.postorder();

    return 0;
}
