#include<iostream>
#include "doubly.h"

using namespace std;
int main(){
    Doubly doubly;
    doubly.insert(1);
    doubly.insert(8);
    doubly.insert(6);
    doubly.insert(5);
    doubly.insert(7);
    doubly.insert(4);
    doubly.insert(2);
    doubly.insert(5);
    doubly.insert(9);

    cout<<"Before sorting : "<<endl;
    doubly.display();
    cout<<endl;
    doubly.sort();
    cout<<"After sorting : "<<endl;
    doubly.display();
    
}
