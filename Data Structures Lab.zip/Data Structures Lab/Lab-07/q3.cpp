#include<iostream>
#include "stack.h"

using namespace std;

void sortedInsert(stack &s, int element) {
    if (s.isEmpty() || element > s.peek()) {
        s.push(element);
        return;
    }
    int temp = s.pop();
    sortedInsert(s, element);
    s.push(temp);
}

void sortStack(stack &s) {
    if (!s.isEmpty()) {
        int temp = s.pop();
        sortStack(s);
        sortedInsert(s, temp);
    }
}

int main(){
    stack s;
    s.push(3);
    s.push(1);
    s.push(4);
    s.push(2);
    s.push(5);
    
    cout << "Stack before sorting: ";
    s.display();

    sortStack(s);

    cout << "Stack after sorting: ";
    s.display();
    
}