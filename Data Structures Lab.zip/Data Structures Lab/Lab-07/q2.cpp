#include <iostream>
#include "Queue.h"

using namespace std;

void generateBinaryNumbers(int N, Queue &q)
{
    q.enqueue("1");

    for (int i = 0; i < N; i++)
    {
        string front = q.dequeue();
        cout << front << endl;

        q.enqueue(front + "0");
        q.enqueue(front + "1");
    }
}

int main()
{
    Queue queue;

    generateBinaryNumbers(5, queue);
}