#ifndef DOUBLY
#define DOUBLY

#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node *next;
    Node *prev;

    Node(int data = 0)
    {
        this->data = data;
        this->next = nullptr;
        this->prev = nullptr;
    }
};

class Doubly
{
public:
    Node *head;
    Node *tail;

    Doubly()
    {
        this->head = nullptr;
        this->tail = nullptr;
    }

    void insert(int data = 0)
    {
        Node *newNode = new Node(data);
        if (head == nullptr)
        {
            head = newNode;
            tail = newNode;
        }
        else
        {
            newNode->prev = tail;
            tail->next = newNode;
            tail = newNode;
        }
    }

    void display()
    {
        Node *temp = head;
        while (temp != nullptr)
        {
            cout << temp->data << " -> ";
            temp = temp->next;
        }
        cout << "Null" << endl;
    }
    void swapNodes(Node *&head, Node *&tail, Node *a, Node *b)
    {
        if (a == b || !a || !b)
            return;

        if (head == a)
            head = b;
        else if (head == b)
            head = a;

        if (tail == a)
            tail = b;
        else if (tail == b)
            tail = a;

        if (a->prev)
            a->prev->next = b;
        if (b->prev)
            b->prev->next = a;

        if (a->next)
            a->next->prev = b;
        if (b->next)
            b->next->prev = a;

        Node *tempPrev = a->prev;
        a->prev = b->prev;
        b->prev = tempPrev;

        Node *tempNext = a->next;
        a->next = b->next;
        b->next = tempNext;

        if (a->next == a)
            a->next = b;
        if (b->next == b)
            b->next = a;
    }

    void sort()
    {
        if (!head || !head->next)
            return;

        bool swapped;
        Node *lptr = nullptr;

        do
        {
            swapped = false;
            Node *ptr1 = head;

            while (ptr1->next != lptr)
            {
                if (ptr1->data > ptr1->next->data)
                {
                    swap(ptr1->data, ptr1->next->data);
                    swapped = true;
                }
                ptr1 = ptr1->next;
            }
            lptr = ptr1;
        } while (swapped);
    }
};
#endif
