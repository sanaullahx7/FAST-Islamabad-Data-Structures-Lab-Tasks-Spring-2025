#ifndef QUEUE
#define QUEUE

#include <iostream>
using namespace std;

class Node
{
public:
    string data;
    Node *next;

    Node(string data = "")
    {
        this->data = data;
        this->next = nullptr;
    }
};

class Queue
{
public:
    Node *head;
    Node *tail;

    Queue()
    {
        this->head = nullptr;
        this->tail = nullptr;
    }

    void enqueue(string data)
    {
        Node *newNode = new Node(data);
        if (head == nullptr)
        {
            head = tail = newNode;
            return;
        }
        tail->next = newNode;
        tail = newNode;
    }

    string dequeue()
    {
        if (head == nullptr)
        {
            cout << "Queue is Empty!\n";
            return "";
        }
        Node *temp = head;
        string frontData = head->data;
        head = head->next;
        if (head == nullptr)
        {
            tail = nullptr;
        }
        delete temp;
        return frontData;
    }

    bool isEmpty()
    {
        return head == nullptr;
    }
};

#endif
