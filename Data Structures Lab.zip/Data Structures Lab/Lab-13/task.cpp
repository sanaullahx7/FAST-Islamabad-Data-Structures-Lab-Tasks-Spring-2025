#include <iostream>
using namespace std;

const int SIZE = 5;

int main() {
    int adjMatrix[SIZE][SIZE] = {0};

    int roads[][2] = {
        {0, 1},
        {0, 2},
        {1, 3},
        {2, 3},
        {3, 4}
    };

    int numRoads = sizeof(roads) / sizeof(roads[0]);

    for (int i = 0; i < numRoads; i++) {
        int u = roads[i][0];
        int v = roads[i][1];
        adjMatrix[u][v] = 1;
        adjMatrix[v][u] = 1;
    }

    cout << "Adjacency Matrix:\n";
    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            cout << adjMatrix[i][j] << " ";
        }
        cout << endl;
    }

    int a, b;
    cout << "\nEnter two node numbers to check for a road: ";
    cin >> a >> b;

    if (a >= 0 && a < SIZE && b >= 0 && b < SIZE) {
        if (adjMatrix[a][b] == 1) {
            cout << "Yes, there is a direct road between " << a << " and " << b << ".\n";
        } else {
            cout << "No, there is no direct road between " << a << " and " << b << ".\n";
        }
    } else {
        cout << "Invalid node numbers entered.\n";
    }

    cout << "\nDegrees:\n";
    for (int i = 0; i < SIZE; i++) {
        int degree = 0;
        for (int j = 0; j < SIZE; j++) {
            degree += adjMatrix[i][j];
        }
        cout << "Location " << i << " has " << degree << " connections.\n";
    }

    return 0;
}
 